# Predictions

This is where your predictions for the test splits will be saved to.
Before running `prepare_submit.py`, make sure that the two subfolders have been populated!
